module.exports = {
  project: {
    android: {
      packageName: 'com.dummyapp.nativeandroid',
      sourceDir: '../app',
    },
  },
  dependencies: {},
};

