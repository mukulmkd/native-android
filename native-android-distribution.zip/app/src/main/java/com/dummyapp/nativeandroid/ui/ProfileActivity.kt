package com.dummyapp.nativeandroid.ui

import com.dummyapp.nativeandroid.R

class ProfileActivity : SimpleModuleActivity() {
    override val titleRes: Int = R.string.title_profile
    override val descriptionRes: Int = R.string.description_profile
}

