package com.dummyapp.nativeandroid.ui

import com.dummyapp.nativeandroid.R

class HomeActivity : SimpleModuleActivity() {
    override val titleRes: Int = R.string.title_home
    override val descriptionRes: Int = R.string.description_home
}

