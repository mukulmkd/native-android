package com.dummyapp.nativeandroid.ui

import com.dummyapp.nativeandroid.R

class SettingsActivity : SimpleModuleActivity() {
    override val titleRes: Int = R.string.title_settings
    override val descriptionRes: Int = R.string.description_settings
}

